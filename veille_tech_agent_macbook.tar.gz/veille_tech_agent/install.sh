#!/bin/bash
# =============================================================================
# Veille Tech Agent — Script d'installation automatique pour macOS (MacBook)
# Compatible Apple Silicon (M1/M2/M3/M4) et Intel
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "============================================================"
echo "🍏 Installation de Veille Tech Agent sur MacBook (macOS)"
echo "============================================================"

# 1. Vérification de Python 3
echo "[1/5] Vérification de l'environnement Python..."
if ! command -v python3 &>/dev/null; then
    echo "❌ Python 3 n'est pas installé."
    echo "👉 Installez Python 3 via Homebrew ('brew install python') ou Xcode Command Line Tools ('xcode-select --install')."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✓ Python version détectée : $PYTHON_VERSION"

# 2. Création de l'environnement virtuel venv
echo "[2/5] Configuration de l'environnement virtuel (venv)..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "✓ Environnement virtuel créé dans ./venv"
else
    echo "✓ Environnement virtuel existant détecté dans ./venv"
fi

# 3. Installation des dépendances
echo "[3/5] Installation des dépendances Python..."
"$SCRIPT_DIR/venv/bin/pip" install --upgrade pip --quiet
"$SCRIPT_DIR/venv/bin/pip" install -r requirements.txt --quiet
echo "✓ Dépendances installées avec succès."

# 4. Arborescence de stockage des données
echo "[4/5] Vérification de l'arborescence des données..."
mkdir -p data/raw data/summaries data/newsletters
echo "✓ Dossiers data/ prêts."

# 5. Configuration de l'environnement (.env)
echo "[5/5] Configuration des variables d'environnement..."
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo "⚠️  Un fichier .env a été créé à partir de .env.example."
        echo "👉 Renseignez votre GEMINI_API_KEY dans le fichier .env ou lancez ./run.sh configure."
    fi
else
    echo "✓ Fichier .env existant conservé."
fi

# Droits d'exécution sur les scripts
chmod +x *.sh 2>/dev/null || true

echo ""
echo "============================================================"
echo "🎉 Installation terminée avec succès !"
echo "============================================================"
echo ""
echo "Commandes rapides :"
echo "  • Configurer l'agent (LLM, clés) : ./run.sh configure"
echo "  • Lancer la veille quotidienne    : ./run.sh daily"
echo "  • Générer la newsletter hebdo     : ./run.sh weekly"
echo "  • Générer & envoyer par email     : ./run.sh weekly --send-email"
echo "  • Installer les tâches cron auto  : ./setup_cron.sh"
echo "============================================================"
