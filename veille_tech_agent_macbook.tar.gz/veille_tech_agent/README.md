# 🏛️ Veille Tech Agent — Système Multi-Agents de Veille Stratégique SI

Système multi-agents autonome de veille technologique et stratégique conçu pour les **Architectes d'Entreprise** (spécialisé Banque, Assurance, Énergie, Systèmes Distribués et IA Agentique).

---

## 🚀 Déploiement Rapide sur MacBook (macOS)

Ce projet est optimisé pour macOS (Apple Silicon M1/M2/M3/M4 & Intel).

### 1. Prérequis
* Un MacBook sous macOS (12 Monterey, 13 Ventura, 14 Sonoma, 15 Sequoia ou ultérieur).
* **Python 3.10+** (inclus par défaut avec Xcode CLI Tools `xcode-select --install` ou via Homebrew `brew install python`).
* Une clé API Google Gemini (gratuite sur [Google AI Studio](https://aistudio.google.com/app/apikey)).

### 2. Installation en 1 commande

Ouvrez le Terminal dans le dossier du projet et lancez :

```bash
./install.sh
```

Le script s'occupe de tout :
1. Détection de votre environnement Python macOS.
2. Création de l'environnement virtuel isolé (`./venv`).
3. Installation des dépendances requises (`requirements.txt`).
4. Création de l'arborescence de données (`data/raw`, `data/summaries`, `data/newsletters`).
5. Préparation du fichier `.env`.

---

## ⚙️ Configuration

### Clé API & Modèle LLM
Vous pouvez renseigner votre clé API soit :
* Directement dans le fichier `.env` :
  ```env
  GEMINI_API_KEY="votre_cle_api"
  EMAIL_SENDER="votre.email@gmail.com" # Optionnel
  ```
* Ou via l'assistant interactif :
  ```bash
  ./run.sh configure
  ```

### Sources de Veille
Les flux RSS et newsletters sont configurés dans `config/sources.yaml` :
* **Cloud & Infrastructure** : AWS Architecture, Microsoft Azure, Netflix TechBlog, Cloudflare, Uber Eng, Last Week in AWS, ByteByteGo, Off-by-none...
* **Ingénierie Logicielle & Modernisation** : Martin Fowler, Gregor Hohpe, Refactoring.fm, InfoQ, TLDR Tech...
* **Data, IA Agentique & Banques** : Capital One Tech, Neo4j, Claude Dev, Simon Wardley (Gardeviance), IBM Cloud & watsonx, Google Cloud Community...

---

## 💻 Utilisation Quotidienne

Des raccourcis simples sont fournis via `./run.sh` :

```bash
# 1. Collecte quotidienne et filtrage LLM des articles du jour
./run.sh daily

# 2. Rédaction de la newsletter hebdomadaire (Markdown prêt à publier)
./run.sh weekly

# 3. Rédaction et envoi automatique par email
./run.sh weekly --send-email

# 4. Assistant de configuration interactive
./run.sh configure
```

Les newsletters générées sont sauvegardées automatiquement dans `data/newsletters/newsletter_AAAA-MM-JJ.md`.

---

## 🕒 Automatisation sur macOS (Crontab)

Pour que votre MacBook exécute la veille en arrière-plan :
* **Collecte quotidienne** : tous les matins à 06h00.
* **Génération hebdomadaire** : tous les dimanches soir à 19h00.

Lancez l'assistant automatique :
```bash
./setup_cron.sh
```

*(Ou configurez manuellement votre crontab via `crontab -e`)*.

---

## 📂 Structure du Projet

```text
veille_tech_agent/
├── agents/                  # Multi-agents Python
│   ├── collector.py         # Collecte RSS & extraction d'images/infographies
│   ├── evaluator.py         # Scoring & résumés structurés par IA (score >= 7/10)
│   ├── writer.py            # Synthèse hebdomadaire, Wardley Map & projets pilotes
│   ├── mailer.py            # Envoi SMTP sécurisé en HTML/Markdown
│   └── llm_client.py        # Client unifié (Gemini / WatsonX / Ollama)
├── config/
│   ├── sources.yaml         # Liste des flux RSS et médias surveillés
│   ├── email_config.yaml    # Paramètres SMTP et destinataires
│   └── llm_config.yaml      # Paramètres du modèle LLM
├── data/
│   ├── raw/                 # Articles bruts ingérés (JSON)
│   ├── summaries/           # Résumés évalués (JSON)
│   └── newsletters/         # Newsletters finales publiées (Markdown)
├── install.sh               # Script d'installation automatique macOS
├── run.sh                   # Lanceur rapide en CLI
├── setup_cron.sh            # Assistant d'automatisation crontab
├── cron_daily.sh            # Script cron quotidien
├── cron_weekly.sh           # Script cron hebdomadaire
├── configure.py             # Assistant interactif de configuration
├── requirements.txt         # Dépendances Python
├── .env.example             # Modèle de variables d'environnement
└── README.md                # Documentation complète
```
