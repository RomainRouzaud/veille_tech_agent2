#!/bin/bash
# =============================================================================
# Veille Tech Agent — Assistant Crontab macOS
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "============================================================"
echo "🕒 Assistant de planification Crontab pour macOS"
echo "============================================================"
echo "Ce script configure la crontab de votre MacBook pour :"
echo "  1. Collecte quotidienne à 06h00 (du lundi au dimanche)"
echo "  2. Génération de la newsletter le dimanche soir à 19h00"
echo ""
echo "Commandes programmées :"
echo "  • Quotidien (06h00) : $SCRIPT_DIR/cron_daily.sh"
echo "  • Hebdo (Dim 19h00) : $SCRIPT_DIR/cron_weekly.sh"
echo "------------------------------------------------------------"
echo ""

read -p "Voulez-vous installer ces tâches dans votre crontab ? (o/N) : " response
if [[ "$response" =~ ^([oO]|[oO][uU][iI]|[yY]|[yY][eE][sS])$ ]]; then
    TMP_CRON=$(mktemp)
    crontab -l 2>/dev/null | grep -v "veille_tech_agent" > "$TMP_CRON" || true
    echo "0 6 * * * $SCRIPT_DIR/cron_daily.sh >> $SCRIPT_DIR/cron_daily.log 2>&1" >> "$TMP_CRON"
    echo "0 19 * * 0 $SCRIPT_DIR/cron_weekly.sh >> $SCRIPT_DIR/cron_weekly.log 2>&1" >> "$TMP_CRON"
    crontab "$TMP_CRON"
    rm "$TMP_CRON"
    echo "✓ Tâches cron installées avec succès !"
    echo ""
    echo "Aperçu des entrées actives dans crontab :"
    crontab -l | grep "veille_tech_agent"
else
    echo "Installation automatique annulée."
    echo "Pour éditer manuellement, tapez : crontab -e"
fi
