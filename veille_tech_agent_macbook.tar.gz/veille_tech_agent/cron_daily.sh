#!/bin/bash
# =============================================================================
# ITGA TechWatch — Daily Ingestion & Evaluation Cron Script
# Planifié : Tous les jours à 06h00
#
# Pour installer le cron, exécutez ./setup_cron.sh ou crontab -e
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON="$SCRIPT_DIR/venv/bin/python"
LOG="$SCRIPT_DIR/cron_daily.log"

echo ""
echo "======================================================"
echo "  ITGA TechWatch Daily — $(date '+%Y-%m-%d %H:%M:%S')"
echo "======================================================"

cd "$SCRIPT_DIR" || exit 1

if [ ! -f "$PYTHON" ]; then
    echo "ERREUR: Environnement virtuel introuvable dans $PYTHON"
    echo "Veuillez exécuter ./install.sh au préalable."
    exit 1
fi

"$PYTHON" main.py --mode daily

echo "======================================================"
echo "  Terminé à $(date '+%Y-%m-%d %H:%M:%S')"
echo "======================================================"
