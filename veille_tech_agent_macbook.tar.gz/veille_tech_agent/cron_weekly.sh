#!/bin/bash
# =============================================================================
# ITGA TechWatch — Weekly Newsletter Cron Script
# Planifié : Dimanche soir 19h00 (génération) → email reçu avant lundi 06h00
#
# Pour installer le cron, exécutez ./setup_cron.sh ou crontab -e
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON="$SCRIPT_DIR/venv/bin/python"
LOG="$SCRIPT_DIR/cron_weekly.log"

echo ""
echo "======================================================"
echo "  ITGA TechWatch Weekly — $(date '+%Y-%m-%d %H:%M:%S')"
echo "======================================================"

cd "$SCRIPT_DIR" || exit 1

if [ ! -f "$PYTHON" ]; then
    echo "ERREUR: Environnement virtuel introuvable dans $PYTHON"
    echo "Veuillez exécuter ./install.sh au préalable."
    exit 1
fi

# 1. Collecte et évaluation des articles de la semaine
echo "[1/2] Lancement du job daily pour s'assurer d'avoir les derniers articles..."
"$PYTHON" main.py --mode daily

# 2. Génération newsletter + envoi email
echo "[2/2] Génération newsletter hebdomadaire + envoi email..."
"$PYTHON" main.py --mode weekly --send-email

echo "======================================================"
echo "  Terminé à $(date '+%Y-%m-%d %H:%M:%S')"
echo "======================================================"
