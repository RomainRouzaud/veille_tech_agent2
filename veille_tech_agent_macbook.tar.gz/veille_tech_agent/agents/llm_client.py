"""
LLM Client abstraction layer.
Supports multiple providers: Gemini, Ollama, IBM WatsonX (BAM).
Provider and config are loaded from config/llm_config.yaml.
"""
import os
import yaml
import json
import requests
from dotenv import load_dotenv

load_dotenv()

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "llm_config.yaml")


def load_llm_config() -> dict:
    """Load LLM configuration from YAML file."""
    if not os.path.exists(CONFIG_PATH):
        # Default to Gemini if no config exists yet
        return {"provider": "gemini", "model": "gemini-2.5-flash"}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


class LLMClient:
    """
    Unified LLM client supporting:
      - gemini   : Google Gemini via google-genai SDK
      - ollama   : Local Ollama (gemma, llama, mistral, etc.)
      - watsonx  : IBM WatsonX / BAM via REST API
    """

    def __init__(self):
        self.config = load_llm_config()
        self.provider = self.config.get("provider", "gemini")
        self.model = self.config.get("model", "gemini-2.0-flash")

    def generate(self, prompt: str, json_mode: bool = False) -> str | None:
        """
        Generate a response from the configured LLM.
        Returns the text response, or None on error.
        """
        if self.provider == "gemini":
            return self._generate_gemini(prompt, json_mode)
        elif self.provider == "ollama":
            return self._generate_ollama(prompt, json_mode)
        elif self.provider == "watsonx":
            return self._generate_watsonx(prompt, json_mode)
        else:
            print(f"[LLM] Provider inconnu: {self.provider}")
            return None

    # ------------------------------------------------------------------
    # Gemini (Google)
    # ------------------------------------------------------------------
    def _generate_gemini(self, prompt: str, json_mode: bool) -> str | None:
        try:
            from google import genai
            from google.genai import types

            api_key = os.environ.get("GEMINI_API_KEY") or self.config.get("api_key")
            if not api_key:
                print("[Gemini] GEMINI_API_KEY manquante.")
                return None

            # Gemini API requires the full 'models/' prefix
            model_name = self.model
            if not model_name.startswith("models/"):
                model_name = f"models/{model_name}"

            client = genai.Client(api_key=api_key)
            kwargs = {}
            if json_mode:
                kwargs["config"] = types.GenerateContentConfig(
                    response_mime_type="application/json"
                )
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                **kwargs
            )
            return response.text
        except Exception as e:
            print(f"[Gemini] Erreur: {e}")
            return None

    # ------------------------------------------------------------------
    # Ollama (local)
    # ------------------------------------------------------------------
    def _generate_ollama(self, prompt: str, json_mode: bool) -> str | None:
        try:
            base_url = self.config.get("base_url", "http://localhost:11434")
            url = f"{base_url}/api/generate"
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
            }
            if json_mode:
                payload["format"] = "json"

            resp = requests.post(url, json=payload, timeout=120)
            resp.raise_for_status()
            return resp.json().get("response", "")
        except Exception as e:
            print(f"[Ollama] Erreur: {e}")
            return None

    # ------------------------------------------------------------------
    # IBM WatsonX / BAM
    # ------------------------------------------------------------------
    def _generate_watsonx(self, prompt: str, json_mode: bool) -> str | None:
        try:
            api_key = os.environ.get("WATSONX_API_KEY") or self.config.get("api_key")
            project_id = os.environ.get("WATSONX_PROJECT_ID") or self.config.get("project_id")
            base_url = self.config.get(
                "base_url",
                "https://eu-de.ml.cloud.ibm.com/ml/v1/text/generation?version=2023-05-29"
            )

            if not api_key or not project_id:
                print("[WatsonX] WATSONX_API_KEY ou WATSONX_PROJECT_ID manquants.")
                return None

            # Obtain IAM bearer token
            iam_resp = requests.post(
                "https://iam.cloud.ibm.com/identity/token",
                data={
                    "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
                    "apikey": api_key,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30
            )
            iam_resp.raise_for_status()
            bearer = iam_resp.json().get("access_token")

            payload = {
                "model_id": self.model,
                "input": prompt,
                "parameters": {
                    "max_new_tokens": 2048,
                    "temperature": 0.3,
                },
                "project_id": project_id,
            }

            resp = requests.post(
                base_url,
                json=payload,
                headers={
                    "Authorization": f"Bearer {bearer}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
                timeout=120
            )
            resp.raise_for_status()
            results = resp.json().get("results", [])
            if results:
                return results[0].get("generated_text", "")
            return None
        except Exception as e:
            print(f"[WatsonX] Erreur: {e}")
            return None
